from django.db import models

# Create your models here.
from django.db import models
from django.contrib.auth import get_user_model

user = get_user_model()

